1. Install
2. Enter credential and download data
3. Enjoy
